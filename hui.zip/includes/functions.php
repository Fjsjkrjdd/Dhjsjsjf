<?php
/** Общие функции-помощники. */

// --- Полифилы для PHP 7.4 (функции появились в PHP 8.0) -----------------
if (!function_exists('str_starts_with')) {
    function str_starts_with($haystack, $needle)
    {
        return $needle === '' || strncmp((string) $haystack, (string) $needle, strlen((string) $needle)) === 0;
    }
}
if (!function_exists('str_ends_with')) {
    function str_ends_with($haystack, $needle)
    {
        $needle = (string) $needle;
        return $needle === '' || substr((string) $haystack, -strlen($needle)) === $needle;
    }
}
if (!function_exists('str_contains')) {
    function str_contains($haystack, $needle)
    {
        return $needle === '' || strpos((string) $haystack, (string) $needle) !== false;
    }
}

require_once __DIR__ . '/db.php';

/* ----------------------------- Базовое -------------------------------- */

function app_config(): array
{
    static $cfg = null;
    if ($cfg === null) {
        $cfg = require __DIR__ . '/../config.php';
    }
    return $cfg;
}

/** Экранирование для вывода в HTML. */
function e(?string $s): string
{
    return htmlspecialchars($s ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Базовый URL сайта (с учётом подкаталога). */
function base_url(): string
{
    static $base = null;
    if ($base !== null) {
        return $base;
    }
    $cfg = app_config();
    if (!empty($cfg['base_url'])) {
        return $base = rtrim($cfg['base_url'], '/');
    }
    $https  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $scheme = $https ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';

    // Веб-путь к корню приложения (= каталог, где лежит index.php),
    // вычисляется относительно DOCUMENT_ROOT — корректно и в подпапке, и в /admin.
    $rel     = '';
    $appRoot = realpath(dirname(__DIR__));
    $docRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '');
    if ($appRoot && $docRoot && str_starts_with($appRoot, $docRoot)) {
        $rel = str_replace('\\', '/', substr($appRoot, strlen($docRoot)));
    } else {
        // Запасной вариант: каталог текущего скрипта (без /admin).
        $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
        $dir = preg_replace('#/admin$#', '', $dir);
        $rel = $dir;
    }
    $rel = '/' . trim($rel, '/');
    if ($rel === '/') {
        $rel = '';
    }
    return $base = $scheme . '://' . $host . $rel;
}

/** Ссылка на публичную страницу (ЧПУ). */
function url(string $path = ''): string
{
    $path = ltrim($path, '/');
    return base_url() . '/' . $path;
}

/** Ссылка на статический ресурс / загруженный файл. */
function asset(string $path): string
{
    if ($path === '') {
        return '';
    }
    if (preg_match('#^https?://#', $path)) {
        return $path;
    }
    return base_url() . '/' . ltrim($path, '/');
}

function admin_url(string $page = '', array $params = []): string
{
    $q = array_merge($page !== '' ? ['p' => $page] : [], $params);
    return base_url() . '/admin/' . ($q ? '?' . http_build_query($q) : '');
}

function redirect(string $to): void
{
    header('Location: ' . $to);
    exit;
}

function format_price(int $n): string
{
    return number_format($n, 0, '.', ' ');
}

function now(): string
{
    return date('Y-m-d H:i:s');
}

/* ----------------------------- Настройки ------------------------------ */

function all_settings(): array
{
    static $s = null;
    if ($s === null) {
        $s = [];
        foreach (db()->query('SELECT skey, svalue FROM settings')->fetchAll() as $row) {
            $s[$row['skey']] = $row['svalue'];
        }
    }
    return $s;
}

function setting(string $key, string $default = ''): string
{
    $s = all_settings();
    return array_key_exists($key, $s) ? (string) $s[$key] : $default;
}

function set_setting(string $key, string $value): void
{
    $driver = db_driver(db());
    if ($driver === 'mysql') {
        $sql = 'INSERT INTO settings (skey, svalue) VALUES (?, ?) ON DUPLICATE KEY UPDATE svalue = VALUES(svalue)';
    } else {
        // INSERT OR REPLACE поддерживается всеми версиями SQLite (без UPSERT 3.24+).
        $sql = 'INSERT OR REPLACE INTO settings (skey, svalue) VALUES (?, ?)';
    }
    db()->prepare($sql)->execute([$key, $value]);
}

/* -------------------------- Текстовые блоки --------------------------- */

function blocks_for(string $page): array
{
    $out = [];
    $st = db()->prepare('SELECT bkey, bvalue FROM content_blocks WHERE page = ? ORDER BY sort ASC');
    $st->execute([$page]);
    foreach ($st->fetchAll() as $row) {
        $out[$row['bkey']] = $row['bvalue'];
    }
    // Подстраховка: если блоков нет (например, добавили новый ключ) — берём дефолты.
    require_once __DIR__ . '/blocks.php';
    $defaults = block_defaults()[$page] ?? [];
    foreach ($defaults as $k => $def) {
        if (!array_key_exists($k, $out)) {
            $out[$k] = $def['value'];
        }
    }
    return $out;
}

/* ----------------------------- Соцсети -------------------------------- */

function social_links(): array
{
    $links = [];
    $add = function (string $key, string $label, ?string $href) use (&$links) {
        if ($href) {
            $links[] = ['key' => $key, 'label' => $label, 'href' => $href];
        }
    };
    $add('vk', 'ВКонтакте', setting('vk') ?: null);
    $tg = setting('telegram');
    if ($tg) {
        $add('telegram', 'Telegram', str_starts_with($tg, 'http') ? $tg : 'https://t.me/' . ltrim($tg, '@'));
    }
    $wa = setting('whatsapp');
    if ($wa) {
        $add('whatsapp', 'WhatsApp', str_starts_with($wa, 'http') ? $wa : 'https://wa.me/' . preg_replace('/\D/', '', $wa));
    }
    $add('instagram', 'Instagram', setting('instagram') ?: null);
    $add('youtube', 'YouTube', setting('youtube') ?: null);
    $max = setting('max');
    if ($max) {
        $add('max', 'MAX', str_starts_with($max, 'http') ? $max : 'https://max.ru/' . ltrim($max, '@'));
    }
    $add('yandex', 'Яндекс Карты', setting('yandex_maps') ?: null);
    return $links;
}

function tel_href(string $phone): string
{
    return 'tel:' . preg_replace('/[^0-9+]/', '', $phone);
}

function email_href(string $email): string
{
    return 'mailto:' . trim($email);
}

/** Ссылки для плавающей кнопки контактов. Управляются из настроек сайта. */
function floating_contact_links(): array
{
    $links = [];
    $add = function (string $key, string $label, string $href) use (&$links) {
        $href = trim($href);
        if ($href !== '') {
            $links[] = ['key' => $key, 'label' => $label, 'href' => $href];
        }
    };

    if (setting('floating_contacts_show_whatsapp', '1') === '1') {
        $wa = setting('whatsapp');
        if ($wa) {
            $add('whatsapp', 'WhatsApp', str_starts_with($wa, 'http') ? $wa : 'https://wa.me/' . preg_replace('/\D/', '', $wa));
        }
    }
    if (setting('floating_contacts_show_telegram', '1') === '1') {
        $tg = setting('telegram');
        if ($tg) {
            $add('telegram', 'Telegram', str_starts_with($tg, 'http') ? $tg : 'https://t.me/' . ltrim($tg, '@'));
        }
    }
    if (setting('floating_contacts_show_max', '1') === '1') {
        $max = setting('max');
        if ($max) {
            $add('max', 'MAX', str_starts_with($max, 'http') ? $max : 'https://max.ru/' . ltrim($max, '@'));
        }
    }
    if (setting('floating_contacts_show_vk', '1') === '1' && setting('vk')) {
        $add('vk', 'ВКонтакте', setting('vk'));
    }
    if (setting('floating_contacts_show_phone', '1') === '1' && setting('phone')) {
        $add('phone', 'Позвонить', tel_href(setting('phone')));
    }
    if (setting('floating_contacts_show_email', '1') === '1' && setting('email')) {
        $add('email', 'Написать на e-mail', email_href(setting('email')));
    }
    if (setting('floating_contacts_show_yandex', '0') === '1' && setting('yandex_maps')) {
        $add('yandex', 'Яндекс Карты', setting('yandex_maps'));
    }
    return $links;
}

/* ------------------------------ Загрузка ------------------------------ */

function upload_image(string $field): string
{
    $files = upload_images($field);
    return $files ? $files[0] : '';
}

/** Загрузка одного или нескольких изображений из поля формы. */
function upload_images(string $field): array
{
    if (empty($_FILES[$field])) {
        return [];
    }
    $file = $_FILES[$field];
    if (!is_array($file['name'])) {
        $one = upload_image_file($file);
        return $one ? [$one] : [];
    }
    $out = [];
    $count = count($file['name']);
    for ($i = 0; $i < $count; $i++) {
        if (($file['error'][$i] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            continue;
        }
        $single = [
            'name'     => $file['name'][$i],
            'type'     => $file['type'][$i],
            'tmp_name' => $file['tmp_name'][$i],
            'error'    => $file['error'][$i],
            'size'     => $file['size'][$i],
        ];
        $path = upload_image_file($single);
        if ($path) {
            $out[] = $path;
        }
    }
    return $out;
}

function upload_image_file(array $file): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return '';
    }
    // SVG не принимаем: в нём может быть JavaScript.
    // Большие фото с телефона лучше сжимать до загрузки, иначе хостинг может оборвать POST.
    if (($file['size'] ?? 0) > 10 * 1024 * 1024) {
        return '';
    }
    $allowed = [
        'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp',
        'image/gif' => 'gif',
    ];
    $tmp  = $file['tmp_name'];
    $mime = $file['type'];
    if (function_exists('finfo_open')) {
        $f = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($f, $tmp) ?: $mime;
        finfo_close($f);
    }
    if (!isset($allowed[$mime])) {
        return '';
    }
    $ext = $allowed[$mime];
    $dir = __DIR__ . '/../uploads';
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    $name = bin2hex(random_bytes(8)) . '.' . $ext;
    if (!move_uploaded_file($tmp, $dir . '/' . $name)) {
        return '';
    }
    return 'uploads/' . $name;
}


/** Загрузка видео для блока на главной. */
function upload_video(string $field): string
{
    if (empty($_FILES[$field]) || ($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return '';
    }
    return upload_video_file($_FILES[$field]);
}

function upload_video_file(array $file): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return '';
    }
    // Лимит выбран с запасом под короткое видео. При необходимости увеличьте post_max_size/upload_max_filesize на хостинге.
    if (($file['size'] ?? 0) > 120 * 1024 * 1024) {
        return '';
    }
    $allowed = [
        'video/mp4' => 'mp4',
        'video/webm' => 'webm',
        'video/ogg' => 'ogv',
        'video/quicktime' => 'mov',
    ];
    $tmp  = $file['tmp_name'];
    $mime = $file['type'] ?? '';
    if (function_exists('finfo_open')) {
        $f = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($f, $tmp) ?: $mime;
        finfo_close($f);
    }
    if (!isset($allowed[$mime])) {
        return '';
    }
    $ext = $allowed[$mime];
    $dir = __DIR__ . '/../uploads/video';
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    $name = bin2hex(random_bytes(8)) . '.' . $ext;
    if (!move_uploaded_file($tmp, $dir . '/' . $name)) {
        return '';
    }
    return 'uploads/video/' . $name;
}

/** JSON-галерея изображений услуги. */
function service_gallery(array $service): array
{
    $images = [];
    if (!empty($service['image'])) {
        $images[] = $service['image'];
    }
    if (!empty($service['gallery'])) {
        $extra = json_decode($service['gallery'], true);
        if (is_array($extra)) {
            foreach ($extra as $img) {
                if ($img && !in_array($img, $images, true)) {
                    $images[] = $img;
                }
            }
        }
    }
    return $images;
}

/** CSS-переменные цветовой темы из настроек. */
function theme_css_tag(): string
{
    $defaults = [
        'color_cream' => '#faf7f2', 'color_cream_deep' => '#f3ede3',
        'color_sage' => '#6f8f7f', 'color_sage_dark' => '#4f6f60', 'color_sage_light' => '#e7efe9',
        'color_terracotta' => '#c98a6b', 'color_terracotta_dark' => '#b5734f',
        'color_ink' => '#2c322f', 'color_ink_soft' => '#5b635e',
    ];
    $vars = [];
    foreach ($defaults as $key => $def) {
        $val = setting($key, $def);
        if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $val)) {
            $val = $def;
        }
        $cssKey = str_replace('color_', '', $key);
        $cssKey = str_replace('_', '-', $cssKey);
        $vars[] = '--' . $cssKey . ':' . $val;
    }
    return '<style id="site-theme">:root{' . implode(';', $vars) . '}</style>';
}

/* ------------------------------- Прочее ------------------------------- */

function slugify(string $s): string
{
    $map = [
        'а'=>'a','б'=>'b','в'=>'v','г'=>'g','д'=>'d','е'=>'e','ё'=>'e','ж'=>'zh','з'=>'z',
        'и'=>'i','й'=>'y','к'=>'k','л'=>'l','м'=>'m','н'=>'n','о'=>'o','п'=>'p','р'=>'r',
        'с'=>'s','т'=>'t','у'=>'u','ф'=>'f','х'=>'h','ц'=>'c','ч'=>'ch','ш'=>'sh','щ'=>'sch',
        'ъ'=>'','ы'=>'y','ь'=>'','э'=>'e','ю'=>'yu','я'=>'ya',
    ];
    $s = mb_strtolower($s, 'UTF-8');
    $s = strtr($s, $map);
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    $s = trim($s, '-');
    return $s !== '' ? substr($s, 0, 80) : 'item-' . time();
}

function format_date_ru(string $datetime): string
{
    $months = [1=>'января',2=>'февраля',3=>'марта',4=>'апреля',5=>'мая',6=>'июня',
        7=>'июля',8=>'августа',9=>'сентября',10=>'октября',11=>'ноября',12=>'декабря'];
    $ts = strtotime($datetime) ?: time();
    return (int) date('j', $ts) . ' ' . $months[(int) date('n', $ts)] . ' ' . date('Y', $ts);
}

/** Иконка соцсети (inline SVG). */
function social_icon_svg(string $key): string
{
    $i = [
       'vk' => '<img class="social-icon-img social-icon-vk" src="' . e(asset('assets/img/icons/vk.svg')) . '" alt="ВКонтакте">',
        'telegram' => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M21.9 4.3 18.7 19c-.2 1-.9 1.3-1.8.8l-4.8-3.6-2.3 2.2c-.3.3-.5.5-1 .5l.3-4.9 8.9-8c.4-.3-.1-.5-.6-.2L6.5 13.1l-4.7-1.5c-1-.3-1-1 .2-1.5l18.4-7.1c.9-.3 1.6.2 1.5 1.3Z"/></svg>',
        'whatsapp' => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.5 15.2L2 22l4.9-1.4A10 10 0 1 0 12 2Zm0 18a8 8 0 0 1-4.1-1.1l-.3-.2-2.9.8.8-2.8-.2-.3A8 8 0 1 1 12 20Zm4.4-5.6c-.2-.1-1.4-.7-1.7-.8-.2-.1-.4-.1-.5.1l-.7.9c-.1.2-.3.2-.5.1a6.5 6.5 0 0 1-3.2-2.8c-.2-.4.2-.4.6-1.2.1-.1 0-.3 0-.4l-.8-1.9c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3c-.3.3-.9.9-.9 2.1s.9 2.5 1 2.6c.1.2 1.8 2.8 4.4 3.9 1.6.7 2.3.7 3.1.6.5-.1 1.4-.6 1.6-1.1.2-.6.2-1 .1-1.1l-.1-.1Z"/></svg>',
        'instagram' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r="1" fill="currentColor" stroke="none"/></svg>',
        'youtube' => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M22 8.2a3 3 0 0 0-2.1-2.1C18 5.5 12 5.5 12 5.5s-6 0-7.9.6A3 3 0 0 0 2 8.2 31 31 0 0 0 1.7 12 31 31 0 0 0 2 15.8a3 3 0 0 0 2.1 2.1c1.9.6 7.9.6 7.9.6s6 0 7.9-.6a3 3 0 0 0 2.1-2.1c.3-1.9.3-3.8.3-3.8s0-1.9-.3-3.8ZM10 15V9l5.2 3-5.2 3Z"/></svg>',
        // Не просто «X»: читаемая иконка MAX в круге. При необходимости её легко заменить на фирменный SVG-файл.
        'max' => '<img class="social-icon-img social-icon-max" src="' . e(asset('assets/img/icons/max.svg')) . '" alt="MAX">',
       'yandex' => '<img class="social-icon-img social-icon-yandex" src="' . e(asset('assets/img/icons/yandex.svg')) . '" alt="Яндекс Карты">',
        'phone' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.4 19.4 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.6a2 2 0 0 1-.5 2.1L8 9.6a16 16 0 0 0 6.4 6.4l1.2-1.2a2 2 0 0 1 2.1-.5c.8.3 1.7.5 2.6.6A2 2 0 0 1 22 16.9Z"/></svg>',
        'email' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></svg>',
        'chat' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.5 8.5 0 0 1-9 8.5 9.6 9.6 0 0 1-4.2-1L3 20l1.2-4.1A8.3 8.3 0 0 1 3 11.5a8.5 8.5 0 0 1 18 0Z"/><path d="M8 10h8M8 14h5"/></svg>',
    ];
    return $i[$key] ?? $i['chat'];
}

/** Иконка услуги (inline SVG). */
function service_icon(string $name): string
{
    $icons = [
        'user'     => '<circle cx="12" cy="8" r="4"/><path d="M4 20c0-3.3 3.6-6 8-6s8 2.7 8 6"/>',
        'users'    => '<circle cx="9" cy="8" r="3.2"/><path d="M2.5 20c0-3 3-5.2 6.5-5.2s6.5 2.2 6.5 5.2"/><path d="M16 5.5a3 3 0 0 1 0 5.8M17.5 14.6c2.4.6 4 2.4 4 5.4"/>',
        'palette'  => '<path d="M12 3a9 9 0 1 0 0 18c1.7 0 2-1.3 1.2-2.2-.8-.9-.5-2.3.9-2.3H17a4 4 0 0 0 4-4c0-4.7-4-9.5-9-9.5Z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="14.5" cy="7.5" r="1"/>',
        'sparkles' => '<path d="M12 3l1.8 4.7L18.5 9.5 13.8 11.3 12 16l-1.8-4.7L5.5 9.5l4.7-1.8L12 3Z"/><path d="M18 14l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8.8-2Z"/>',
        'video'    => '<rect x="2.5" y="6" width="13" height="12" rx="2"/><path d="M15.5 10l6-3v10l-6-3"/>',
        'heart'    => '<path d="M12 20s-7-4.4-9.2-9C1.4 8 2.8 4.8 6 4.8c2 0 3.2 1.2 4 2.4.8-1.2 2-2.4 4-2.4 3.2 0 4.6 3.2 3.2 6.2C19 15.6 12 20 12 20Z"/>',
    ];
    $body = $icons[$name] ?? $icons['heart'];
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' . $body . '</svg>';
}
/* ---------------------- Расширенная админка / SEO ---------------------- */

function menu_items(string $location = 'header', bool $onlyActive = true): array
{
    try {
        $sql = 'SELECT * FROM menu_items WHERE location = ?';
        if ($onlyActive) {
            $sql .= ' AND is_active = 1';
        }
        $sql .= ' ORDER BY sort ASC, id ASC';
        $st = db()->prepare($sql);
        $st->execute([$location]);
        $items = $st->fetchAll();
        if ($items) {
            return $items;
        }
    } catch (Throwable $e) {
        // На старой базе до миграции вернём встроенное меню.
    }
    return [
        ['label' => 'Главная', 'url' => '', 'location' => $location, 'sort' => 10, 'is_active' => 1],
        ['label' => 'Услуги и цены', 'url' => 'services', 'location' => $location, 'sort' => 20, 'is_active' => 1],
        ['label' => 'Обо мне', 'url' => 'about', 'location' => $location, 'sort' => 30, 'is_active' => 1],
        ['label' => 'Отзывы', 'url' => 'reviews', 'location' => $location, 'sort' => 40, 'is_active' => 1],
        ['label' => 'Статьи', 'url' => 'articles', 'location' => $location, 'sort' => 50, 'is_active' => 1],
        ['label' => 'Контакты', 'url' => 'contacts', 'location' => $location, 'sort' => 60, 'is_active' => 1],
    ];
}

function menu_item_href(string $raw): string
{
    $raw = trim($raw);
    if ($raw === '') {
        return url();
    }
    if (preg_match('#^(https?:)?//#i', $raw) || preg_match('#^(tel:|mailto:)#i', $raw)) {
        return $raw;
    }
    return url(ltrim($raw, '/'));
}

function menu_item_active(string $itemUrl, string $currentRoute): bool
{
    $itemUrl = trim($itemUrl, '/');
    $currentRoute = trim($currentRoute, '/');
    if ($itemUrl === '') {
        return $currentRoute === '';
    }
    if (preg_match('#^(https?:)?//#i', $itemUrl) || preg_match('#^(tel:|mailto:)#i', $itemUrl)) {
        return false;
    }
    return $currentRoute === $itemUrl || str_starts_with($currentRoute, $itemUrl . '/');
}

function order_statuses(): array
{
    return [
        'new' => 'Новая',
        'contacted' => 'Связались',
        'booked' => 'Записана',
        'paid' => 'Оплачена',
        'cancelled' => 'Отменена',
        'done' => 'Завершена',
    ];
}

function order_status_label(string $status): string
{
    $map = order_statuses();
    return $map[$status] ?? $status;
}

function faqs_for_page(string $slug = '', string $location = 'all'): array
{
    try {
        $st = db()->prepare("SELECT * FROM faqs WHERE is_active = 1 AND (page_slug = '' OR page_slug = ? OR location = ?) ORDER BY sort ASC, id ASC");
        $st->execute([$slug, $location]);
        return $st->fetchAll();
    } catch (Throwable $e) {
        return [];
    }
}

function notify_http_post_json(string $url, array $headers, array $payload, int $timeout = 8): array
{
    $body = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_HTTPHEADER => array_merge(['Content-Type: application/json'], $headers),
            CURLOPT_POSTFIELDS => $body,
        ]);
        $response = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        return ['ok' => $code >= 200 && $code < 300, 'code' => $code, 'error' => $error, 'response' => (string) $response];
    }
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => implode("\r\n", array_merge(['Content-Type: application/json'], $headers)),
            'content' => $body,
            'timeout' => $timeout,
            'ignore_errors' => true,
        ],
    ]);
    $response = @file_get_contents($url, false, $context);
    $code = 0;
    if (!empty($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) {
        $code = (int) $m[1];
    }
    return ['ok' => $code >= 200 && $code < 300, 'code' => $code, 'error' => $response === false ? 'request failed' : '', 'response' => (string) $response];
}

function notify_http_post_text(string $url, array $headers, string $body, int $timeout = 8): array
{
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POSTFIELDS => $body,
        ]);
        $response = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        return ['ok' => $code >= 200 && $code < 300, 'code' => $code, 'error' => $error, 'response' => (string) $response];
    }
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => implode("\r\n", $headers),
            'content' => $body,
            'timeout' => $timeout,
            'ignore_errors' => true,
        ],
    ]);
    $response = @file_get_contents($url, false, $context);
    $code = 0;
    if (!empty($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) {
        $code = (int) $m[1];
    }
    return ['ok' => $code >= 200 && $code < 300, 'code' => $code, 'error' => $response === false ? 'request failed' : '', 'response' => (string) $response];
}

function notify_telegram(string $text): array
{
    if (setting('notify_telegram_enabled', '0') !== '1') {
        return ['ok' => false, 'skipped' => true, 'channel' => 'telegram', 'error' => 'disabled'];
    }
    $token = trim(setting('notify_telegram_bot_token'));
    $chatId = trim(setting('notify_telegram_chat_id'));
    if ($token === '' || $chatId === '') {
        return ['ok' => false, 'channel' => 'telegram', 'error' => 'empty token or chat id'];
    }
    $url = 'https://api.telegram.org/bot' . rawurlencode($token) . '/sendMessage';
    $res = notify_http_post_json($url, [], [
        'chat_id' => $chatId,
        'text' => $text,
        'disable_web_page_preview' => true,
    ]);
    $res['channel'] = 'telegram';
    return $res;
}

function notify_ntfy(string $text): array
{
    if (setting('notify_ntfy_enabled', '0') !== '1') {
        return ['ok' => false, 'skipped' => true, 'channel' => 'ntfy', 'error' => 'disabled'];
    }
    $topic = trim(setting('notify_ntfy_topic'));
    if ($topic === '') {
        return ['ok' => false, 'channel' => 'ntfy', 'error' => 'empty topic'];
    }
    $server = rtrim(setting('notify_ntfy_server', 'https://ntfy.sh'), '/');
    if ($server === '') {
        $server = 'https://ntfy.sh';
    }
    $url = $server . '/' . rawurlencode($topic);
    $res = notify_http_post_text($url, [
        'Title: Новая заявка с сайта',
        'Priority: high',
        'Tags: bell',
    ], $text);
    $res['channel'] = 'ntfy';
    return $res;
}

function notify_send_message(string $text): array
{
    $results = [];
    $results[] = notify_telegram($text);
    $results[] = notify_ntfy($text);
    foreach ($results as $r) {
        if (!empty($r['ok'])) {
            return $results;
        }
    }
    error_log('Site notification failed: ' . json_encode($results, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    return $results;
}

function notify_new_order(array $order): array
{
    $adminUrl = trim(setting('notify_admin_url', '/admin/?p=orders'));
    if ($adminUrl !== '' && !preg_match('#^https?://#i', $adminUrl)) {
        $adminUrl = base_url() . '/' . ltrim($adminUrl, '/');
    }
    $lines = [
        'Новая заявка с сайта ' . setting('site_name'),
        '',
        'Имя: ' . ($order['customer_name'] ?? ''),
        'Телефон: ' . ($order['customer_phone'] ?? ''),
    ];
    if (!empty($order['customer_email'])) {
        $lines[] = 'E-mail: ' . $order['customer_email'];
    }
    if (!empty($order['service_title'])) {
        $lines[] = 'Услуга: ' . $order['service_title'];
    }
    if (!empty($order['preferred_date'])) {
        $lines[] = 'Удобное время: ' . $order['preferred_date'];
    }
    if (!empty($order['comment'])) {
        $lines[] = '';
        $lines[] = 'Комментарий: ' . $order['comment'];
    }
    if ($adminUrl !== '') {
        $lines[] = '';
        $lines[] = 'Админка: ' . $adminUrl;
    }
    return notify_send_message(implode("\n", $lines));
}

function metrika_tag(): string
{
    $id = trim(setting('yandex_metrika_id'));
    if ($id === '' || !preg_match('/^\d+$/', $id)) {
        return '';
    }
    $idEsc = e($id);
    return <<<HTML
<!-- Yandex.Metrika counter -->
<script>
(function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
m[i].l=1*new Date();
for (var j = 0; j < document.scripts.length; j++) { if (document.scripts[j].src === r) { return; } }
k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
(window, document, 'script', 'https://mc.yandex.ru/metrika/tag.js', 'ym');
ym($idEsc, 'init', {clickmap:true, trackLinks:true, accurateTrackBounce:true, webvisor:true});
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/$idEsc" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
HTML;
}
