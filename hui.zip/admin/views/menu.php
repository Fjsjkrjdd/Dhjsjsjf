<?php /** @var array $items; @var array $pages; @var ?array $edit; @var bool $isNew */
$showForm = $edit || $isNew;
$locationLabels = ['header' => 'Верхнее меню', 'footer' => 'Футер'];
?>
<div class="admin-head">
    <div><h1>Меню сайта</h1><p>Добавляйте в шапку обычные и посадочные страницы без правки кода.</p></div>
    <?php if (!$showForm): ?><a href="<?= e(admin_url('menu', ['new' => 1])) ?>" class="btn btn-primary btn-sm">+ Добавить пункт</a><?php endif; ?>
</div>

<?php if ($showForm): ?>
<form method="post" action="<?= e(admin_url('menu')) ?>" class="adm-card">
    <?= csrf_field() ?>
    <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int) $edit['id'] ?>"><?php endif; ?>
    <div class="adm-grid cols-2">
        <div class="adm-field"><label>Название пункта *</label><input name="label" required value="<?= e($edit['label'] ?? '') ?>" placeholder="Семейный психолог"></div>
        <div class="adm-field"><label>Куда ведёт</label><input name="url" list="pageUrls" value="<?= e($edit['url'] ?? '') ?>" placeholder="Например: psiholog-online или contacts"></div>
    </div>
    <datalist id="pageUrls">
        <option value="">Главная</option>
        <option value="services">Услуги и цены</option>
        <option value="about">Обо мне</option>
        <option value="reviews">Отзывы</option>
        <option value="articles">Статьи</option>
        <option value="contacts">Контакты</option>
        <option value="booking">Запись</option>
        <?php foreach ($pages as $p): ?><option value="<?= e($p['slug']) ?>"><?= e($p['title']) ?></option><?php endforeach; ?>
    </datalist>
    <div class="adm-grid cols-3">
        <div class="adm-field"><label>Где показывать</label><select name="location"><?php foreach ($locationLabels as $k=>$v): ?><option value="<?= e($k) ?>" <?= ($edit['location'] ?? 'header') === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?></select></div>
        <div class="adm-field"><label>Порядок</label><input type="number" name="sort" value="<?= (int) ($edit['sort'] ?? 70) ?>"></div>
        <label class="adm-check"><input type="checkbox" name="is_active" <?= ($edit['is_active'] ?? 1) ? 'checked' : '' ?>> Показывать</label>
    </div>
    <p class="adm-hint">Можно указать полный URL, например ссылку на внешний ресурс. Для внутренних страниц достаточно slug без слеша.</p>
    <div class="adm-actions"><button class="btn btn-primary">Сохранить</button><a href="<?= e(admin_url('menu')) ?>" class="btn btn-outline btn-sm">Отмена</a></div>
</form>
<?php else: ?>
    <?php foreach ($items as $m): ?>
        <div class="adm-list-item <?= empty($m['is_active']) ? 'adm-section-off' : '' ?>">
            <div>
                <strong><?= e($m['label']) ?></strong>
                <span class="adm-tag"><?= e($locationLabels[$m['location']] ?? $m['location']) ?></span>
                <?php if (empty($m['is_active'])): ?><span class="adm-tag">скрыт</span><?php endif; ?>
                <div class="muted" style="font-size:.85rem">Ссылка: <code><?= e($m['url'] === '' ? '/' : $m['url']) ?></code> · порядок <?= (int) $m['sort'] ?></div>
            </div>
            <div class="adm-actions">
                <a href="<?= e(admin_url('menu', ['id' => $m['id']])) ?>" class="btn btn-outline btn-sm">Изменить</a>
                <form method="post" action="<?= e(admin_url('menu')) ?>" onsubmit="return confirm('Удалить пункт меню?')">
                    <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $m['id'] ?>">
                    <button class="btn-danger">Удалить</button>
                </form>
            </div>
        </div>
    <?php endforeach; ?>
    <?php if (!$items): ?><div class="adm-card">Пункты меню ещё не добавлены.</div><?php endif; ?>
<?php endif; ?>
