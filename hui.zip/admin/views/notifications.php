<?php /** @var array $s */
$v = function ($k, $d = '') use ($s) { return e(isset($s[$k]) ? $s[$k] : $d); };
?>
<form method="post" action="<?= e(admin_url('notifications')) ?>">
    <?= csrf_field() ?>
    <div class="admin-head"><div><h1>Уведомления о заявках</h1><p>Новая заявка будет сохраняться в админке и дополнительно приходить в выбранные каналы.</p></div><button class="btn btn-primary">Сохранить</button></div>

    <div class="adm-card">
        <h2>Ссылка на админку в уведомлении</h2>
        <div class="adm-field"><label>URL</label><input name="notify_admin_url" value="<?= $v('notify_admin_url', '/admin/?p=orders') ?>"><span class="adm-hint">Можно оставить относительный путь: /admin/?p=orders</span></div>
    </div>

    <div class="adm-card">
        <h2>Telegram</h2>
        <label class="adm-check"><input type="checkbox" name="notify_telegram_enabled" <?= ($s['notify_telegram_enabled'] ?? '0') === '1' ? 'checked' : '' ?>> Включить Telegram-уведомления</label>
        <div class="adm-grid cols-2">
            <div class="adm-field"><label>Bot Token</label><input type="password" name="notify_telegram_bot_token" value="<?= $v('notify_telegram_bot_token') ?>" placeholder="123456:ABC..."></div>
            <div class="adm-field"><label>Chat ID</label><input name="notify_telegram_chat_id" value="<?= $v('notify_telegram_chat_id') ?>" placeholder="123456789"></div>
        </div>
        <p class="adm-hint">Бота создают через BotFather. Chat ID можно получить через getUpdates после сообщения боту.</p>
    </div>

    <div class="adm-card">
        <h2>ntfy</h2>
        <label class="adm-check"><input type="checkbox" name="notify_ntfy_enabled" <?= ($s['notify_ntfy_enabled'] ?? '0') === '1' ? 'checked' : '' ?>> Включить ntfy-уведомления</label>
        <div class="adm-grid cols-2">
            <div class="adm-field"><label>Сервер</label><input name="notify_ntfy_server" value="<?= $v('notify_ntfy_server', 'https://ntfy.sh') ?>"></div>
            <div class="adm-field"><label>Topic</label><input name="notify_ntfy_topic" value="<?= $v('notify_ntfy_topic') ?>" placeholder="chernova-zayavki-secret"></div>
        </div>
        <p class="adm-hint">В приложении ntfy нужно подписаться на этот topic. Сделайте topic длинным и секретным.</p>
    </div>

    <div class="adm-card">
        <h2>SMS-резерв</h2>
        <div class="adm-field"><label>Заметка / будущий API</label><textarea name="notify_sms_note" rows="3"><?= $v('notify_sms_note') ?></textarea><span class="adm-hint">Пока оставил как поле под будущую интеграцию SMS.ru/SMS Aero/Exolve. Основной рабочий вариант уже есть через Telegram/ntfy.</span></div>
    </div>

    <div class="adm-actions">
        <button class="btn btn-primary">Сохранить</button>
        <button class="btn btn-outline" name="action" value="test">Сохранить и отправить тест</button>
    </div>
</form>
