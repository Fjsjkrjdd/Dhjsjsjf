<?php /** @var array $items; @var ?array $edit; @var bool $isNew */
$showForm = $edit || $isNew;
?>
<div class="admin-head">
    <div><h1>Посадочные страницы</h1><p>SEO-страницы под запросы: семейный психолог, тревога, отношения, онлайн и т.д.</p></div>
    <?php if (!$showForm): ?><a href="<?= e(admin_url('landing-pages', ['new' => 1])) ?>" class="btn btn-primary btn-sm">+ Добавить посадочную</a><?php endif; ?>
</div>

<?php if ($showForm): ?>
<form method="post" action="<?= e(admin_url('landing-pages')) ?>" enctype="multipart/form-data" class="adm-card">
    <?= csrf_field() ?>
    <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int) $edit['id'] ?>"><?php endif; ?>

    <div class="adm-grid cols-2">
        <div class="adm-field"><label>Название в админке *</label><input name="title" required value="<?= e($edit['title'] ?? '') ?>" placeholder="Семейный психолог Ростов-на-Дону"></div>
        <div class="adm-field"><label>URL / slug *</label><input name="slug" value="<?= e($edit['slug'] ?? '') ?>" placeholder="semeinyi-psiholog-rostov-na-donu"><span class="adm-hint">Пусто — сгенерируется автоматически.</span></div>
    </div>

    <div class="adm-field"><label>H1 на странице</label><input name="h1" value="<?= e($edit['h1'] ?? '') ?>" placeholder="Семейный психолог в Ростове-на-Дону"></div>
    <div class="adm-field"><label>Короткий лид под заголовком</label><textarea name="excerpt" rows="3"><?= e($edit['excerpt'] ?? '') ?></textarea></div>

    <div class="adm-grid cols-2">
        <div class="adm-field"><label>Обложка</label><input name="cover" value="<?= e($edit['cover'] ?? '') ?>" placeholder="uploads/photo.jpg"><input type="file" name="cover_file" accept="image/*"></div>
        <div class="adm-field"><label>Порядок</label><input type="number" name="sort" value="<?= (int) ($edit['sort'] ?? 100) ?>"></div>
    </div>

    <div class="adm-field"><label>Основной текст HTML</label><textarea name="body" rows="18"><?= e($edit['body'] ?? '') ?></textarea><span class="adm-hint">Структура: кому подходит, с чем обращаться, как проходит, цена, формат, CTA.</span></div>

    <div class="adm-grid cols-2">
        <div class="adm-field"><label>Заголовок CTA-блока</label><input name="cta_title" value="<?= e($edit['cta_title'] ?? '') ?>" placeholder="Запишитесь на консультацию"></div>
        <div class="adm-field"><label>Текст CTA-блока</label><textarea name="cta_text" rows="3"><?= e($edit['cta_text'] ?? '') ?></textarea></div>
    </div>

    <div class="adm-card nested">
        <h2>SEO</h2>
        <div class="adm-field"><label>Title</label><input name="meta_title" value="<?= e($edit['meta_title'] ?? '') ?>"></div>
        <div class="adm-field"><label>Description</label><textarea name="meta_description" rows="2"><?= e($edit['meta_description'] ?? '') ?></textarea></div>
        <div class="adm-field"><label>Canonical</label><input name="canonical" value="<?= e($edit['canonical'] ?? '') ?>" placeholder="Обычно оставить пустым"></div>
        <div class="adm-grid cols-2">
            <div class="adm-field"><label>OG title</label><input name="og_title" value="<?= e($edit['og_title'] ?? '') ?>"></div>
            <div class="adm-field"><label>OG image</label><input name="og_image" value="<?= e($edit['og_image'] ?? '') ?>"><input type="file" name="og_image_file" accept="image/*"></div>
        </div>
        <div class="adm-field"><label>OG description</label><textarea name="og_description" rows="2"><?= e($edit['og_description'] ?? '') ?></textarea></div>
    </div>

    <div class="adm-card nested">
        <h2>Меню</h2>
        <label class="adm-check"><input type="checkbox" name="is_in_menu" <?= ($edit['is_in_menu'] ?? 0) ? 'checked' : '' ?>> Добавить страницу в верхнее меню</label>
        <div class="adm-grid cols-2">
            <div class="adm-field"><label>Название в меню</label><input name="menu_title" value="<?= e($edit['menu_title'] ?? '') ?>" placeholder="Если пусто — название страницы"></div>
            <div class="adm-field"><label>Порядок в меню</label><input type="number" name="menu_sort" value="<?= (int) ($edit['menu_sort'] ?? 70) ?>"></div>
        </div>
    </div>

    <label class="adm-check"><input type="checkbox" name="is_published" <?= ($edit['is_published'] ?? 1) ? 'checked' : '' ?>> Опубликована</label>
    <div class="adm-actions"><button class="btn btn-primary">Сохранить</button><a href="<?= e(admin_url('landing-pages')) ?>" class="btn btn-outline btn-sm">Отмена</a></div>
</form>
<?php else: ?>
    <div class="adm-card">
        <p class="muted">Примеры URL: <code>semeinyi-psiholog-rostov-na-donu</code>, <code>psiholog-pri-trevoge</code>, <code>psiholog-online</code>, <code>psiholog-po-otnosheniyam</code>.</p>
    </div>
    <?php foreach ($items as $p): ?>
        <div class="adm-list-item">
            <div>
                <strong><?= e($p['title']) ?></strong>
                <?php if (!$p['is_published']): ?><span class="adm-tag">скрыта</span><?php endif; ?>
                <?php if (!empty($p['is_in_menu'])): ?><span class="adm-tag">в меню</span><?php endif; ?>
                <div class="muted" style="font-size:.85rem"><a href="<?= e(url($p['slug'])) ?>" target="_blank">/<?= e($p['slug']) ?> ↗</a></div>
            </div>
            <div class="adm-actions">
                <a href="<?= e(admin_url('landing-pages', ['id' => $p['id']])) ?>" class="btn btn-outline btn-sm">Изменить</a>
                <form method="post" action="<?= e(admin_url('landing-pages')) ?>" onsubmit="return confirm('Удалить посадочную страницу?')">
                    <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
                    <button class="btn-danger">Удалить</button>
                </form>
            </div>
        </div>
    <?php endforeach; ?>
    <?php if (!$items): ?><div class="adm-card">Посадочные страницы ещё не добавлены.</div><?php endif; ?>
<?php endif; ?>
