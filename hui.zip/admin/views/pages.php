<?php /** @var array $items; @var ?array $edit; @var bool $isNew */
$showForm = $edit || $isNew;
?>
<div class="admin-head">
    <div><h1>Обычные страницы</h1><p>Политика, оферта и другие текстовые страницы сайта.</p></div>
    <?php if (!$showForm): ?><a href="<?= e(admin_url('pages', ['new' => 1])) ?>" class="btn btn-primary btn-sm">+ Добавить страницу</a><?php endif; ?>
</div>

<?php if ($showForm): ?>
<form method="post" action="<?= e(admin_url('pages')) ?>" enctype="multipart/form-data" class="adm-card">
    <?= csrf_field() ?>
    <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int) $edit['id'] ?>"><?php endif; ?>
    <input type="hidden" name="page_type" value="standard">

    <div class="adm-grid cols-2">
        <div class="adm-field"><label>Название *</label><input name="title" required value="<?= e($edit['title'] ?? '') ?>"></div>
        <div class="adm-field"><label>URL / slug</label><input name="slug" value="<?= e($edit['slug'] ?? '') ?>"><span class="adm-hint">Например: privacy или oferta</span></div>
    </div>
    <div class="adm-field"><label>H1</label><input name="h1" value="<?= e($edit['h1'] ?? '') ?>" placeholder="Если пусто — будет название"></div>
    <div class="adm-field"><label>Текст страницы HTML</label><textarea name="body" rows="16"><?= e($edit['body'] ?? '') ?></textarea><span class="adm-hint">Можно вставлять HTML: &lt;h2&gt;, &lt;p&gt;, &lt;ul&gt;, &lt;strong&gt;.</span></div>

    <div class="adm-card nested">
        <h2>SEO</h2>
        <div class="adm-field"><label>Title</label><input name="meta_title" value="<?= e($edit['meta_title'] ?? '') ?>"></div>
        <div class="adm-field"><label>Description</label><textarea name="meta_description" rows="2"><?= e($edit['meta_description'] ?? '') ?></textarea></div>
        <div class="adm-field"><label>Canonical</label><input name="canonical" value="<?= e($edit['canonical'] ?? '') ?>" placeholder="Обычно оставить пустым"></div>
    </div>

    <div class="adm-grid cols-3">
        <label class="adm-check"><input type="checkbox" name="is_published" <?= ($edit['is_published'] ?? 1) ? 'checked' : '' ?>> Опубликована</label>
        <label class="adm-check"><input type="checkbox" name="is_in_menu" <?= ($edit['is_in_menu'] ?? 0) ? 'checked' : '' ?>> Добавить в верхнее меню</label>
        <div class="adm-field"><label>Порядок</label><input type="number" name="sort" value="<?= (int) ($edit['sort'] ?? 0) ?>"></div>
    </div>
    <div class="adm-grid cols-2">
        <div class="adm-field"><label>Название в меню</label><input name="menu_title" value="<?= e($edit['menu_title'] ?? '') ?>" placeholder="Если пусто — название страницы"></div>
        <div class="adm-field"><label>Порядок в меню</label><input type="number" name="menu_sort" value="<?= (int) ($edit['menu_sort'] ?? 70) ?>"></div>
    </div>

    <div class="adm-actions"><button class="btn btn-primary">Сохранить</button><a href="<?= e(admin_url('pages')) ?>" class="btn btn-outline btn-sm">Отмена</a></div>
</form>
<?php else: ?>
    <?php foreach ($items as $p): ?>
        <div class="adm-list-item">
            <div>
                <strong><?= e($p['title']) ?></strong>
                <?php if (!$p['is_published']): ?><span class="adm-tag">скрыта</span><?php endif; ?>
                <?php if (!empty($p['is_in_menu'])): ?><span class="adm-tag">в меню</span><?php endif; ?>
                <div class="muted" style="font-size:.85rem"><a href="<?= e(url($p['slug'])) ?>" target="_blank">/<?= e($p['slug']) ?> ↗</a></div>
            </div>
            <div class="adm-actions">
                <a href="<?= e(admin_url('pages', ['id' => $p['id']])) ?>" class="btn btn-outline btn-sm">Изменить</a>
                <form method="post" action="<?= e(admin_url('pages')) ?>" onsubmit="return confirm('Удалить страницу?')">
                    <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
                    <button class="btn-danger">Удалить</button>
                </form>
            </div>
        </div>
    <?php endforeach; ?>
    <?php if (!$items): ?><div class="adm-card">Страницы ещё не добавлены.</div><?php endif; ?>
<?php endif; ?>
