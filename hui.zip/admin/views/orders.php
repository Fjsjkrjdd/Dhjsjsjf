<?php /** @var array $items */
$statuses = order_statuses();
?>
<div class="admin-head"><div><h1>Заявки и оплаты</h1><p>Статусы, оплата и внутренние заметки по клиентам.</p></div></div>

<?php foreach ($items as $o): ?>
    <div class="adm-list-item order-item">
        <div class="order-main">
            <div>
                <strong>#<?= (int) $o['id'] ?> · <?= e($o['customer_name']) ?></strong>
                <span class="adm-tag status-<?= e($o['status']) ?>"><?= e(order_status_label($o['status'])) ?></span>
                <?php if (($o['payment_status'] ?? '') === 'succeeded'): ?><span class="adm-tag">оплата прошла</span><?php endif; ?>
            </div>
            <div class="muted" style="font-size:.9rem;margin-top:.3rem">
                <?= e($o['service_title']) ?> · <?= e($o['customer_phone']) ?><?= $o['customer_email'] ? ' · ' . e($o['customer_email']) : '' ?>
            </div>
            <?php if ($o['preferred_date']): ?><div class="muted" style="font-size:.9rem">Удобное время: <?= e($o['preferred_date']) ?></div><?php endif; ?>
            <?php if ($o['comment']): ?><div class="order-comment"><?= nl2br(e($o['comment'])) ?></div><?php endif; ?>
            <div class="muted" style="font-size:.82rem;margin-top:.35rem">Создана: <?= e($o['created_at']) ?><?= $o['amount'] ? ' · ' . format_price((int) $o['amount']) . ' ₽' : '' ?></div>
        </div>
        <form method="post" action="<?= e(admin_url('orders')) ?>" class="order-admin-form">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int) $o['id'] ?>">
            <div class="adm-field compact"><label>Статус</label><select name="status"><?php foreach ($statuses as $k=>$label): ?><option value="<?= e($k) ?>" <?= $o['status'] === $k ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?></select></div>
            <div class="adm-field compact"><label>Внутренняя заметка</label><textarea name="admin_note" rows="3" placeholder="Видно только в админке"><?= e($o['admin_note'] ?? '') ?></textarea></div>
            <div class="adm-actions">
                <button class="btn btn-primary btn-sm">Сохранить</button>
                <button class="btn-danger" name="action" value="delete" onclick="return confirm('Удалить заявку?')">Удалить</button>
            </div>
        </form>
    </div>
<?php endforeach; ?>
<?php if (!$items): ?><div class="adm-card">Заявок пока нет.</div><?php endif; ?>
