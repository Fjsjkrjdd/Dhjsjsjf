<?php /** @var array $items; @var array $pages; @var ?array $edit; @var bool $isNew */
$showForm = $edit || $isNew;
$locs = ['all' => 'Везде / общие', 'home' => 'Главная', 'landing' => 'Посадочные', 'booking' => 'Запись'];
?>
<div class="admin-head">
    <div><h1>FAQ</h1><p>Вопросы и ответы для главной и посадочных страниц.</p></div>
    <?php if (!$showForm): ?><a href="<?= e(admin_url('faq', ['new' => 1])) ?>" class="btn btn-primary btn-sm">+ Добавить вопрос</a><?php endif; ?>
</div>

<?php if ($showForm): ?>
<form method="post" action="<?= e(admin_url('faq')) ?>" class="adm-card">
    <?= csrf_field() ?>
    <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int) $edit['id'] ?>"><?php endif; ?>
    <div class="adm-field"><label>Вопрос *</label><input name="question" required value="<?= e($edit['question'] ?? '') ?>"></div>
    <div class="adm-field"><label>Ответ HTML</label><textarea name="answer" rows="7"><?= e($edit['answer'] ?? '') ?></textarea></div>
    <div class="adm-grid cols-3">
        <div class="adm-field"><label>Страница</label><input name="page_slug" list="faqPages" value="<?= e($edit['page_slug'] ?? '') ?>" placeholder="Пусто — для всех"><span class="adm-hint">Например: psiholog-pri-trevoge</span></div>
        <div class="adm-field"><label>Группа</label><select name="location"><?php foreach ($locs as $k=>$v): ?><option value="<?= e($k) ?>" <?= ($edit['location'] ?? 'all') === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?></select></div>
        <div class="adm-field"><label>Порядок</label><input type="number" name="sort" value="<?= (int) ($edit['sort'] ?? 100) ?>"></div>
    </div>
    <datalist id="faqPages"><?php foreach ($pages as $p): ?><option value="<?= e($p['slug']) ?>"><?= e($p['title']) ?></option><?php endforeach; ?></datalist>
    <label class="adm-check"><input type="checkbox" name="is_active" <?= ($edit['is_active'] ?? 1) ? 'checked' : '' ?>> Показывать</label>
    <div class="adm-actions"><button class="btn btn-primary">Сохранить</button><a href="<?= e(admin_url('faq')) ?>" class="btn btn-outline btn-sm">Отмена</a></div>
</form>
<?php else: ?>
    <?php foreach ($items as $f): ?>
        <div class="adm-list-item <?= empty($f['is_active']) ? 'adm-section-off' : '' ?>">
            <div>
                <strong><?= e($f['question']) ?></strong>
                <?php if (!empty($f['page_slug'])): ?><span class="adm-tag">/<?= e($f['page_slug']) ?></span><?php endif; ?>
                <span class="adm-tag"><?= e($locs[$f['location']] ?? $f['location']) ?></span>
                <?php if (empty($f['is_active'])): ?><span class="adm-tag">скрыт</span><?php endif; ?>
                <div class="muted" style="font-size:.85rem">Порядок <?= (int) $f['sort'] ?></div>
            </div>
            <div class="adm-actions">
                <a href="<?= e(admin_url('faq', ['id' => $f['id']])) ?>" class="btn btn-outline btn-sm">Изменить</a>
                <form method="post" action="<?= e(admin_url('faq')) ?>" onsubmit="return confirm('Удалить вопрос?')">
                    <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $f['id'] ?>">
                    <button class="btn-danger">Удалить</button>
                </form>
            </div>
        </div>
    <?php endforeach; ?>
    <?php if (!$items): ?><div class="adm-card">FAQ ещё не добавлен.</div><?php endif; ?>
<?php endif; ?>
