<?php
/** Общий макет публичных страниц. @var string $content @var string $page_title */
$title = isset($page_title) && $page_title ? $page_title . ' — ' . setting('site_name') : setting('meta_title');
$desc  = $meta_description ?? setting('meta_description');
$nav = menu_items('header');
$cur = trim($_GET['route'] ?? '', '/');
$cur0 = explode('/', $cur)[0];
?><!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="<?= e(asset('favicon.ico')) ?>" sizes="any">
<link rel="icon" href="<?= e(asset('favicon.svg')) ?>" type="image/svg+xml">
<link rel="apple-touch-icon" href="<?= e(asset('apple-touch-icon.png')) ?>">
<link rel="manifest" href="<?= e(asset('site.webmanifest')) ?>">
    <title><?= e($title) ?></title>
    <meta name="description" content="<?= e($desc) ?>">
    <?php if (!empty($canonical)): ?><link rel="canonical" href="<?= e($canonical) ?>"><?php endif; ?>
    <meta property="og:title" content="<?= e($og_title ?? $title) ?>">
    <meta property="og:description" content="<?= e($og_description ?? $desc) ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?= e($canonical ?? url($cur)) ?>">
    <?php if (!empty($og_image)): ?><meta property="og:image" content="<?= e(asset($og_image)) ?>"><?php endif; ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Manrope:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e(asset('assets/css/style.css')) ?>">
    <?= theme_css_tag() ?>
</head>
<body>
<header class="site-header" id="siteHeader">
    <div class="container header-inner">
        <a href="<?= e(url()) ?>" class="logo">
            <span class="logo-mark">Н</span>
            <span class="logo-text"><?= e(setting('logo_text')) ?></span>
        </a>
        <nav class="main-nav" id="mainNav">
            <?php foreach ($nav as $item): ?>
                <?php $href = (string) ($item['url'] ?? ''); ?>
                <a href="<?= e(menu_item_href($href)) ?>" class="<?= menu_item_active($href, $cur) ? 'active' : '' ?>"><?= e($item['label'] ?? '') ?></a>
            <?php endforeach; ?>
        </nav>
        <div class="header-cta">
            <a href="<?= e(tel_href(setting('phone'))) ?>" class="header-phone"><?= e(setting('phone')) ?></a>
            <a href="<?= e(url('booking')) ?>" class="btn btn-primary btn-sm">Записаться</a>
        </div>
        <button class="nav-toggle" id="navToggle" aria-label="Меню"><span></span><span></span><span></span></button>
    </div>
</header>

<main>
    <?= $content ?>
</main>

<footer class="site-footer">
    <div class="container footer-grid">
        <div>
            <p class="footer-name"><?= e(setting('owner_name')) ?></p>
            <p class="footer-prof"><?= e(setting('profession')) ?></p>
            <p class="footer-tagline"><?= e(setting('tagline')) ?></p>
            <?php $links = social_links(); require __DIR__ . '/partials/social_bar.php'; ?>
        </div>
        <div>
            <h3>Контакты</h3>
            <ul class="footer-list">
                <li><a href="<?= e(tel_href(setting('phone'))) ?>"><?= e(setting('phone')) ?></a></li>
                <li><?= e(setting('address')) ?></li>
                <li><?= e(setting('working_hours')) ?></li>
                <?php if (setting('email')): ?><li><a href="mailto:<?= e(setting('email')) ?>"><?= e(setting('email')) ?></a></li><?php endif; ?>
            </ul>
        </div>
        <div>
            <h3>Разделы</h3>
            <ul class="footer-list">
                <?php $footerMenu = menu_items('footer'); if (!$footerMenu) { $footerMenu = $nav; } ?>
                <?php foreach ($footerMenu as $item): ?>
                    <li><a href="<?= e(menu_item_href((string) ($item['url'] ?? ''))) ?>"><?= e($item['label'] ?? '') ?></a></li>
                <?php endforeach; ?>
                <li><a href="<?= e(url('booking')) ?>">Запись и оплата</a></li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom container">
        <span>© <?= date('Y') ?> <?= e(setting('site_name')) ?>. Все права защищены.</span>
        <span>
            <a href="<?= e(url('privacy')) ?>">Политика конфиденциальности</a>
            · <a href="<?= e(admin_url()) ?>">Вход в админку</a>
        </span>
    </div>
</footer>

<?php require __DIR__ . '/partials/floating_contacts.php'; ?>

<?= metrika_tag() ?>
<script src="<?= e(asset('assets/js/main.js')) ?>"></script>
</body>
</html>
