<?php
/** @var array $section */
$enabled = setting('home_video_enabled', '0') === '1';
$file = trim(setting('home_video_file'));
$urlVideo = trim(setting('home_video_url'));
$poster = trim(setting('home_video_poster'));
if (!$enabled || ($file === '' && $urlVideo === '')) {
    return;
}
$title = $section['title'] ?: setting('home_video_title', 'Познакомьтесь со мной');
$text = $section['body'] ?: setting('home_video_text', 'Короткое видео поможет почувствовать мой подход ещё до первой консультации.');
$src = $file !== '' ? asset($file) : $urlVideo;
$isDirectVideo = $file !== '' || preg_match('#\.(mp4|webm|ogv|mov)(\?.*)?$#i', $urlVideo);
?>
<section class="section video-section" id="video">
    <div class="container video-inner">
        <div class="video-copy">
            <span class="eyebrow">Видео</span>
            <h2><?= e($title) ?></h2>
            <?php if ($text): ?><p class="lead"><?= e($text) ?></p><?php endif; ?>

        </div>
        <div class="video-card">
            <?php if ($isDirectVideo): ?>
                <video controls preload="metadata" playsinline <?= $poster ? 'poster="' . e(asset($poster)) . '"' : '' ?>>
                    <source src="<?= e($src) ?>">
                    Ваш браузер не поддерживает воспроизведение видео.
                </video>
            <?php else: ?>
                <iframe src="<?= e($src) ?>" loading="lazy" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen title="<?= e($title) ?>"></iframe>
            <?php endif; ?>
        </div>
    </div>
</section>