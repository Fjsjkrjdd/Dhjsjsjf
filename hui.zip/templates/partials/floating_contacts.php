<?php
$enabled = setting('floating_contacts_enabled', '1') === '1';
$links = $enabled ? floating_contact_links() : [];
$pos = setting('floating_contacts_position', 'right') === 'left' ? 'left' : 'right';
$showDesktop = setting('floating_contacts_show_desktop', '1') === '1';
$showMobile = setting('floating_contacts_show_mobile', '1') === '1';
$classes = ['floating-contacts', 'floating-contacts-' . $pos];
if (!$showDesktop) { $classes[] = 'fc-hide-desktop'; }
if (!$showMobile) { $classes[] = 'fc-hide-mobile'; }
if ($links): ?>
<div class="<?= e(implode(' ', $classes)) ?>" data-floating-contacts>
    <div class="floating-contacts-panel" aria-label="Контакты">
        <?php foreach ($links as $l): ?>
            <a class="floating-contact-link <?= e($l['key']) ?>" href="<?= e($l['href']) ?>" target="<?= in_array($l['key'], ['phone','email'], true) ? '_self' : '_blank' ?>" rel="noopener" aria-label="<?= e($l['label']) ?>" title="<?= e($l['label']) ?>">
                <?= social_icon_svg($l['key']) ?>
                <span><?= e($l['label']) ?></span>
            </a>
        <?php endforeach; ?>
    </div>
    <button type="button" class="floating-contacts-toggle" data-floating-toggle aria-expanded="false" aria-label="<?= e(setting('floating_contacts_title', 'Связаться')) ?>">
        <span class="fc-open"><?= social_icon_svg('chat') ?></span>
        <span class="fc-close" aria-hidden="true">×</span>
        <span class="fc-label"><?= e(setting('floating_contacts_title', 'Связаться')) ?></span>
    </button>
</div>
<?php endif; ?>
