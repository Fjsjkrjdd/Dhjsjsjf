<?php /** @var array $page */
$isLanding = ($page['page_type'] ?? 'standard') === 'landing';
$h1 = $page['h1'] ?: $page['title'];
?>
<?php if ($isLanding): ?>
    <section class="section landing-hero">
        <div class="container">
            <div class="booking-grid">
                <div>
                    <h1><?= e($h1) ?></h1>
                    <?php if (!empty($page['excerpt'])): ?><p class="lead"><?= nl2br(e($page['excerpt'])) ?></p><?php endif; ?>
                    <div class="hero-actions" style="margin-top:1.2rem">
                        <a href="<?= e(url('booking')) ?>" class="btn btn-primary">Записаться на консультацию</a>
                        <a href="<?= e(tel_href(setting('phone'))) ?>" class="btn btn-outline"><?= e(setting('phone')) ?></a>
                    </div>
                </div>
                <?php if (!empty($page['cover'])): ?>
                    <div class="card" style="padding:0;overflow:hidden">
                        <img src="<?= e(asset($page['cover'])) ?>" alt="<?= e($h1) ?>" style="width:100%;height:100%;min-height:320px;object-fit:cover;display:block">
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php if (!empty($page['body'])): ?>
        <article class="section" style="padding-top:0">
            <div class="container narrow">
                <div class="prose"><?= $page['body'] ?></div>
            </div>
        </article>
    <?php endif; ?>

    <?php $faqs = faqs_for_page($page['slug'], 'landing'); ?>
    <?php if ($faqs): ?>
        <section class="section" style="padding-top:0">
            <div class="container narrow">
                <h2>Частые вопросы</h2>
                <div class="faq-list">
                    <?php foreach ($faqs as $f): ?>
                        <details class="card" style="margin-top:.8rem">
                            <summary style="font-weight:700;cursor:pointer"><?= e($f['question']) ?></summary>
                            <div class="prose" style="margin-top:.8rem"><?= $f['answer'] ?></div>
                        </details>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <section class="cta">
        <div class="container narrow">
            <h2><?= e($page['cta_title'] ?: 'Запишитесь на консультацию') ?></h2>
            <p><?= nl2br(e($page['cta_text'] ?: 'Оставьте заявку, и я свяжусь с вами, чтобы подобрать удобное время.')) ?></p>
            <a href="<?= e(url('booking')) ?>" class="btn btn-white" style="margin-top:1.4rem">Записаться</a>
        </div>
    </section>
<?php else: ?>
    <article class="section">
        <div class="container narrow">
            <h1><?= e($h1) ?></h1>
            <div class="prose"><?= $page['body'] ?></div>
        </div>
    </article>
<?php endif; ?>
