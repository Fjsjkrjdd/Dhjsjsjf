<?php
/** @var array $page */
$canonical = trim($page['canonical'] ?? '');
if ($canonical === '') {
    $canonical = url($page['slug']);
}
render('page', [
    'page'             => $page,
    'page_title'       => $page['meta_title'] ?: ($page['h1'] ?: $page['title']),
    'meta_description' => $page['meta_description'],
    'canonical'        => $canonical,
    'og_title'         => $page['og_title'] ?: ($page['meta_title'] ?: $page['title']),
    'og_description'   => $page['og_description'] ?: $page['meta_description'],
    'og_image'         => $page['og_image'] ?: $page['cover'],
]);
