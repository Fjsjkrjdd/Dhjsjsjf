<?php
/** Приём уведомлений ЮKassa: {BASE_URL}/pay/webhook */
require_once __DIR__ . '/../../includes/yookassa.php';

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);
$obj  = $data['object'] ?? null;
header('Content-Type: application/json');

if (!$obj || empty($obj['id'])) {
    echo json_encode(['ok' => true]);
    exit;
}

$paymentId = (string) $obj['id'];

// Не доверяем телу webhook как источнику истины: любой POST можно подделать.
// Сначала находим заказ по payment_id, затем запрашиваем статус напрямую у ЮKassa.
$st = db()->prepare('SELECT * FROM orders WHERE payment_id = ? LIMIT 1');
$st->execute([$paymentId]);
$order = $st->fetch();
if (!$order) {
    echo json_encode(['ok' => true]);
    exit;
}

$payment = yk_get_payment($paymentId);
if (!$payment || empty($payment['id']) || $payment['id'] !== $paymentId) {
    echo json_encode(['ok' => true]);
    exit;
}

$metaOrderId = (int) ($payment['metadata']['order_id'] ?? 0);
if ($metaOrderId && $metaOrderId !== (int) $order['id']) {
    echo json_encode(['ok' => true]);
    exit;
}

$status = (string) ($payment['status'] ?? $order['payment_status']);
$paid = $status === 'succeeded' || !empty($payment['paid']);
$canceled = $status === 'canceled';

$u = db()->prepare('UPDATE orders SET payment_status=?, status=?, receipt_status=? WHERE id=?');
$u->execute([
    $status,
    $paid ? 'paid' : ($canceled ? 'cancelled' : $order['status']),
    ($paid && $order['receipt_status'] === 'pending') ? 'registered' : $order['receipt_status'],
    $order['id'],
]);

echo json_encode(['ok' => true]);
