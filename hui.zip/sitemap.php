<?php
require_once __DIR__ . '/includes/functions.php';

header('Content-Type: application/xml; charset=UTF-8');

$base = rtrim(app_config()['base_url'] ?: 'https://xn----7sbabjr4bnfkut2e8c2b.xn--p1ai', '/');
$today = date('Y-m-d');

$urls = [
    ['/', '1.00', 'weekly'],
    ['/services', '0.90', 'weekly'],
    ['/about', '0.80', 'monthly'],
    ['/reviews', '0.75', 'weekly'],
    ['/contacts', '0.80', 'monthly'],
    ['/booking', '0.70', 'weekly'],
    ['/articles', '0.60', 'weekly'],
];

try {
    foreach (db()->query('SELECT slug FROM articles WHERE is_published = 1 ORDER BY published_at DESC, id DESC')->fetchAll() as $row) {
        if (!empty($row['slug'])) {
            $urls[] = ['/articles/' . $row['slug'], '0.60', 'weekly'];
        }
    }
    foreach (db()->query('SELECT slug FROM pages WHERE is_published = 1 ORDER BY sort ASC, id ASC')->fetchAll() as $row) {
        if (!empty($row['slug'])) {
            $urls[] = ['/' . $row['slug'], '0.35', 'monthly'];
        }
    }
} catch (Throwable $e) {
    // Если база временно недоступна, отдаём хотя бы основные страницы.
}

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
foreach ($urls as $u) {
    [$path, $priority, $changefreq] = $u;
    $loc = $base . ($path === '/' ? '' : $path);
    echo "  <url>\n";
    echo "    <loc>" . htmlspecialchars($loc, ENT_XML1 | ENT_QUOTES, 'UTF-8') . "</loc>\n";
    echo "    <lastmod>" . $today . "</lastmod>\n";
    echo "    <changefreq>" . htmlspecialchars($changefreq, ENT_XML1 | ENT_QUOTES, 'UTF-8') . "</changefreq>\n";
    echo "    <priority>" . htmlspecialchars($priority, ENT_XML1 | ENT_QUOTES, 'UTF-8') . "</priority>\n";
    echo "  </url>\n";
}
echo "</urlset>\n";
